using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase_5
{
  class Producto
  {
    private string codigoDeBarra;
    private string marca;
    private float precio;

    public string GetMarca()
    {
      return this.marca;
    }

    public float GetPrecio()
    {
      return this.precio;
    }

    public static string MostrarProducto(Producto pro)
    {
      string retorno;
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat("\n Marca: {0}\n Precio:{1}\n Codigo de barras:{2}", pro.marca, pro.precio, pro.codigoDeBarra);
      retorno = sb.ToString();

      return retorno;
    }

    public static explicit operator string(Producto pro)
    {
      return pro.codigoDeBarra;

    }


    public static bool operator !=(Producto pro, string Marca)
    {
      bool retorno;
      if (pro.marca != Marca)
      {
        retorno = true;
      }
      else
      {
        retorno = false;
      }
      return retorno;
    }
    public static bool operator ==(Producto pro, string Marca)
    {
      bool retorno;
      if (pro.marca == Marca)
      {
        retorno = true;

      }
      else
      {
        retorno = false;
      }
      return retorno;

    }
    //***********************************
    public static bool operator ==(Producto pro, Producto pro2)
    {
      bool retorno;
      if (pro is null || pro2 is null)
      {
        retorno = false;
      }
      else
      {
        if (pro.marca == pro2.marca && pro.codigoDeBarra == pro.codigoDeBarra)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
        
      }
    return retorno;

    }
    //***********************************
    public static bool operator !=(Producto pro, Producto pro2)
    {
      return !(pro == pro2);

    }

    //*********************************
    public Producto()
    {

    }
    //*********************************
    public Producto(string mar, string cod, float pre)
    {
      this.marca = mar;
      this.precio = pre;
      this.codigoDeBarra = cod;
    }

  }
}
