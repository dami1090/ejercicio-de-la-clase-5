using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase_5
{
  class Estante
  {
    private Producto[] producto;
    private int ubicacionEstante;

    private Estante(int capacidad)
    {
      this.producto = new Producto[capacidad];
    }
    //***********************************
    public Estante(int capacidad, int ubicacion) : this(capacidad)
    {
      this.ubicacionEstante = ubicacion;

    }
    //***********************************

    public Producto[] GetProduto()
    {
      return this.producto;
    }

    public static string MostrarEstante(Estante est)
    {
      string retorno;
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < est.producto.Length; i++)
      {
        sb.AppendLine(Producto.MostrarProducto(est.producto[i]));
      }
      sb.AppendFormat("\n Producto: {0}\n Ubicacion Estante:{1}\n ", est.producto, est.ubicacionEstante);
      retorno = sb.ToString();

      return retorno;
    }

    /*
     * public static bool operator != (Producto pro, string Marca)
    {
      bool retorno;
      if (pro.marca != Marca)
      {
        retorno = true;
      }
      else
      {
        retorno = false;
      }
      return retorno;      
    }
     */
    public static bool operator !=(Estante est, Producto pro)
    {
      bool retorno = true;
      for (int i = 0; i < est.producto.Length; i++)
      {
        if (est.producto[i] != pro)
        {
          retorno = true;
        }
        else
        {

          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator ==(Estante est, Producto pro)
    {
      bool retorno = true;
      for (int i = 0; i < est.producto.Length; i++)
      {
        if (est.producto[i] == pro)
        {
          retorno = true;
        }
        else
        {

          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator +(Estante est, Producto pro)
    {
      bool retorno;
      int flag = 0;
      int flag2 = 0;
      int pos = 0;
      int i = 0;
      for (; i < est.producto.Length; i++)
      {
        if (est.producto[i] is null) break;
      }
      if (i < est.producto.Length && est != pro)
      {
        est.producto[i] = pro;
        retorno = true;
      }
      else
      {
        retorno = false;
      }
      return retorno;


    }

    public static Estante operator -(Estante est, Producto pro)
    {
      int flag2 = 0;
      int pos = 0;
      bool retorno;
      for (int i = 0; i < est.producto.Length; i++)
      {
        if (est.producto[i] == pro)
        {
          flag2 = 1;
          pos = i;
        }
        else
        {
          flag2 = 0;
        }
      }
      if (flag2 == 1)
      {
        est.producto[pos] = null;

      }
      return est;
    }









  }
}
