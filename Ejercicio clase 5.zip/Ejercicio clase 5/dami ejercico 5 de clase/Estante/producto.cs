﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Producto

    {
        private float precio;
        private string marca;
        private string codigoDeBarra;
        public string GetMarca()
        {
            return this.marca;
        }
        public float GetPrecio()
        {
            return this.precio;
        }
        public string GetCodigo()
        {
            return this.codigoDeBarra;
        }

        public  string MostrarProducto(Producto p )
        {
            string productoCompleto;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Marca: {0}, Precio: {1}, Codigo: {2}",marca,precio,codigoDeBarra);

            productoCompleto = sb.ToString();
            return productoCompleto;
        }
        public static bool operator!=(Producto p1, string marcaca)
        {
            bool flag=false;
            bool retorno;
            flag= string.Equals(p1.marca, marcaca);
            if (flag)
            {
                retorno = false;
            }
            else
                retorno = true;


            return retorno;
        }
        public static bool operator==(Producto p1 , string marcaca)
        {
            bool flag = false;
            bool retorno;
            flag = string.Equals(p1.marca, marcaca);
            if (flag)
            {
                retorno = true;
            }
            else
                retorno = false;


            return retorno;
        }

        public static bool operator ==(Producto p1, Producto p2)
        {
            bool flag = false;
            bool flagMarca;
            bool flagCodigo;
            flagCodigo = string.Equals(p1.codigoDeBarra, p2.codigoDeBarra);
            flagMarca = string.Equals(p1.marca, p2.marca);
            if( flagCodigo && flagMarca)
            {
                flag = true;
            }
           
            return flag;
        }

        public static bool operator !=(Producto p1, Producto p2)
        {
            bool flag = true;
            bool flagMarca;
            bool flagCodigo;
            flagCodigo = string.Equals(p1.codigoDeBarra, p2.codigoDeBarra);
            flagMarca = string.Equals(p1.marca, p2.marca);
            if (flagCodigo && flagMarca)
            {
                flag = false;
            }
            return flag;
        }



    }



    
}
