﻿using System;
using Library;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estante
{
    public class Estante
    {
        private int ubicacionEstante;

        private Producto[] productos; 

        private Estante(int capacidad)
        {
            productos = new Producto[capacidad];
        }
        public Estante(int capacidad, int ubicacion) : this(capacidad)
        {
            this.ubicacionEstante = ubicacion;

        }
        /* public Producto[] GetProductos()
         {


         }*/


        public static bool operator !=(Estante e, Producto p)
        {
            bool retorno = true;
            bool flag = true;
            int i;
            string auxMarca;
            for (i = 0; i < e.productos.Length; i++)
            {
                auxMarca = Producto.GetMarca(e.productos[i]);
               




            }
            

            // flag= string.Equals( e.productos,p.)



            return retorno;
        }
        public static bool operator ==(Estante e, Producto p)
        {
            bool retorno = false;
            return retorno;

        }


    }


}
